/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package siemenscalculadora;


public class SiemensCalculadora 
{


    public static void main(String[] args) 
    {
        //Variable declaration
        int num1 = 6;
        int num2 = 0;
        int NumToThePower = num1;
        int Factorial = num1;
        
        //Addition
        int addition = num1 + num2;
        System.out.println(addition);
        
        //Subtraction
        int subtraction = num1 - num2;
        System.out.println(subtraction);
        
        //Multiplication
        int multiplication = num1 * num2;
        System.out.println(multiplication);
        
        //Division
        float division = (float)num1 / (float)num2;
        System.out.println(division);
        
        //Number to the power Operation
        for(int i=1;i<num2;i++)
        {
            NumToThePower = NumToThePower * num1;
        }
        System.out.println(NumToThePower);
        
        //Factorial
        for(int j=num1-1;j>0;j--)
        {
           Factorial = Factorial*j;
        }
        System.out.println(Factorial);
        
        //Conversion to Binary
        int[] BinaryNum = new int[32];
        int num1Aux = num1;
        int k = 0;
        
        while(num1Aux > 0)
        {
            BinaryNum[k] = num1Aux % 2;
            num1Aux = num1Aux / 2;
            k++;
        }
        for(int l=k;l>=0;l--)
        {
            System.out.print(BinaryNum[l]);
        }
        
    }

}
